#define SPIM_VERSION "Version 9.1.19 of July 25, 2017"
