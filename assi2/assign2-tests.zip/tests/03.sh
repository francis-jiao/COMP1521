# create and delete a linked list
# beware that check only allows 1500 lines of output
./test2
