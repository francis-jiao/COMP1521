# alloc/free with merging
./test3 4000 < data3
