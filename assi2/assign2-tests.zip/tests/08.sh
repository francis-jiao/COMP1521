# just enough space to handle 5 malloc(1000)'s
./test3 5040 < data5
