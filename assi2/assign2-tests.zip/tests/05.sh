# alloc/free with free between alloc'd chunks
./test3 4000 < data2
