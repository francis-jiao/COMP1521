# initHeap ... should make heapSize == 5000
./test1 5000
