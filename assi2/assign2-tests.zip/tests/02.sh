# initHeap ... should make heapSize == 4096
./test1 1000
