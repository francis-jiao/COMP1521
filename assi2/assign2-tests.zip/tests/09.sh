# alloc too much space, test3 ignores failed myMalloc()s
# checking that myMalloc() returns NULL on failure
./test3 4000 < data5
