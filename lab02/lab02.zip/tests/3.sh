./add abc 123
